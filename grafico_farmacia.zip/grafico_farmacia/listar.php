<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$host = "localhost";
$user = "root";
$pass = "";
$db = "grafico_farmacia";

$conexao = new mysqli($host, $user, $pass, $db);

if ($conexao->connect_error) {
    die(json_encode([
        "erro" => "Falha na conexão"
    ]));
}

$sql = "SELECT id, remedio, quantidade FROM venda ORDER BY id ASC";

$resultado = $conexao->query($sql);

$dados = [];

while ($linha = $resultado->fetch_assoc()) {

    $dados[] = [
        "id" => (int) $linha["id"],
        "remedio" => $linha["remedio"],
        "quantidade" => (int) $linha["quantidade"]
    ];

}

echo json_encode($dados);

$conexao->close();

?>
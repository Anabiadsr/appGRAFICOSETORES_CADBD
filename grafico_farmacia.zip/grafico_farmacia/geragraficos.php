<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");


if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

$host = "localhost";
$user = "root";
$pass = "";
$db = "grafico_farmacia";

$conexao = new mysqli($host, $user, $pass, $db);

if ($conexao->connect_error) {
    die(json_encode([
        "erro" => "Falha na conexão"
    ]));
}

$sql = "SELECT remedio, quantidade FROM venda";

$resultado = $conexao->query($sql);

$dados = [];

while ($linha = $resultado->fetch_assoc()) {
    $dados[] = $linha;
}

echo json_encode($dados);

$conexao->close();

?>
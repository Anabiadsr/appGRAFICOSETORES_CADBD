<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    exit;
}

$host = "localhost";
$user = "root";
$pass = "";
$db = "grafico_farmacia";

$conexao = new mysqli($host, $user, $pass, $db);

if ($conexao->connect_error) {
    die(json_encode([
        "sucesso" => false,
        "mensagem" => "Falha na conexão"
    ]));
}

$dados = json_decode(file_get_contents("php://input"), true);

$remedio= $dados["remedio"] ?? "";
$quantidade = $dados["quantidade"] ?? "";

if ($remedio == "" || $quantidade == "") {

    echo json_encode([
        "sucesso" => false,
        "mensagem" => "Preencha todos os campos"
    ]);

    exit;
}

$sql = "INSERT INTO venda (remedio, quantidade)
        VALUES (?, ?)";

$stmt = $conexao->prepare($sql);

$stmt->bind_param(
    "si",
    $remedio,
    $quantidade
);

if ($stmt->execute()) {

    echo json_encode([
        "sucesso" => true,
        "mensagem" => "Venda cadastrada com sucesso"
    ]);

} else {

    echo json_encode([
        "sucesso" => false,
        "mensagem" => "Erro ao cadastrar"
    ]);

}

$stmt->close();
$conexao->close();

?>